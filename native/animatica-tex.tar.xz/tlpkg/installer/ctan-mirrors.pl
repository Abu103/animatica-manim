$mirrors = {
  'Africa' => {
    'Morocco' => {
      'https://mirror.marwan.ma/ctan/' => 1,
    },
    'South Africa' => {
      'https://mirror.ufs.ac.za/ctan/' => 1,
      'https://za.mirrors.cicku.me/ctan/' => 1,
    },
  },
  'Asia' => {
    'China' => {
      'https://mirrors.aliyun.com/CTAN/' => 1,
      'https://mirrors.cloud.tencent.com/CTAN/' => 1,
      'https://mirrors.hit.edu.cn/CTAN/' => 1,
      'https://mirrors.hust.edu.cn/CTAN/' => 1,
      'https://mirrors.jlu.edu.cn/CTAN/' => 1,
      'https://mirrors.nju.edu.cn/CTAN/' => 1,
      'https://mirrors.pku.edu.cn/ctan/' => 1,
      'https://mirrors.qlu.edu.cn/CTAN/' => 1,
      'https://mirrors.sjtug.sjtu.edu.cn/ctan/' => 1,
      'https://mirrors.sustech.edu.cn/CTAN/' => 1,
      'https://mirrors.tuna.tsinghua.edu.cn/CTAN/' => 1,
      'https://mirrors.ustc.edu.cn/CTAN/' => 1,
    },
    'Hong Kong' => {
      'https://mirror-hk.koddos.net/CTAN/' => 1,
    },
    'India' => {
      'https://in.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.niser.ac.in/ctan/' => 1,
      'https://mirrors.in2.sahilister.net/ctan/' => 1,
      'https://mirrors.in3.sahilister.net/ctan/' => 1,
      'https://mirrors.sukhala.in/ctan/' => 1,
    },
    'Indonesia' => {
      'https://mirror.unpad.ac.id/ctan/' => 1,
    },
    'Japan' => {
      'https://ctan.tikz.jp/' => 1,
      'https://ftp.yz.yamagata-u.ac.jp/pub/CTAN/' => 1,
      'https://jp.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.aria-on-the-planet.es/CTAN/' => 1,
      'https://mirror.kris.fail/ctan/' => 1,
    },
    'Korea' => {
      'https://ftp.kaist.ac.kr/ctan/' => 1,
      'https://kr.mirrors.cicku.me/ctan/' => 1,
    },
    'Saudi Arabia' => {
      'https://sa.mirrors.cicku.me/ctan/' => 1,
    },
    'Singapore' => {
      'https://sg.mirrors.cicku.me/ctan/' => 1,
    },
    'Taiwan' => {
      'https://ctan.mirror.twds.com.tw/tex-archive/' => 1,
      'https://tw.mirrors.cicku.me/ctan/' => 1,
    },
    'Thailand' => {
      'https://mirror.kku.ac.th/CTAN/' => 1,
    },
  },
  'Europe' => {
    'Austria' => {
      'https://mirror.kumi.systems/ctan/' => 1,
    },
    'Belarus' => {
      'https://mirror.datacenter.by/pub/mirrors/CTAN/' => 1,
    },
    'Bulgaria' => {
      'https://ftp.uni-sofia.bg/CTAN/' => 1,
      'https://mirrors.neterra.net/CTAN/' => 1,
      'https://mirrors.netix.net/CTAN/' => 1,
    },
    'Czechia' => {
      'https://ftp.cvut.cz/CTAN/' => 1,
      'https://ftp.fi.muni.cz/pub/tex/CTAN/' => 1,
    },
    'Denmark' => {
      'https://mirrors.dotsrc.org/ctan/' => 1,
    },
    'Finland' => {
      'https://ctan.qno.de/' => 1,
      'https://mirror.5i.fi/tex-archive/' => 1,
      'https://www.nic.funet.fi/pub/TeX/CTAN/' => 1,
      'https://www.texlive.info/CTAN/' => 1,
    },
    'France' => {
      'https://ctan.ceremade.dauphine.fr/' => 1,
      'https://ctan.mines-albi.fr/' => 1,
      'https://ctan.sw-servers.net/' => 1,
      'https://ctan.tetaneutral.net/' => 1,
      'https://distrib-coffee.ipsl.jussieu.fr/pub/mirrors/ctan/' => 1,
      'https://mirror.ibcp.fr/pub/CTAN/' => 1,
      'https://mirror.xjj.sh/ctan/' => 1,
      'https://mirrors.ircam.fr/pub/CTAN/' => 1,
    },
    'Germany' => {
      'http://vesta.informatik.rwth-aachen.de/ftp/pub/mirror/ctan/' => 1,
      'https://ctan.ebinger.cc/tex-archive/' => 1,
      'https://ctan.joethei.xyz/' => 1,
      'https://ctan.kcvw.net/' => 1,
      'https://ctan.mirror.norbert-ruehl.de/' => 1,
      'https://ctan.net/' => 1,
      'https://ctan.project-creative.net/' => 1,
      'https://de.mirrors.cicku.me/ctan/' => 1,
      'https://ftp.agdsn.de/pub/mirrors/latex/dante/' => 1,
      'https://ftp.fau.de/ctan/' => 1,
      'https://ftp.gwdg.de/pub/ctan/' => 1,
      'https://ftp.rrze.uni-erlangen.de/ctan/' => 1,
      'https://ftp.rrzn.uni-hannover.de/pub/mirror/tex-archive/' => 1,
      'https://ftp.tu-chemnitz.de/pub/tex/' => 1,
      'https://markov.htwsaar.de/tex-archive/' => 1,
      'https://mirror.clientvps.com/CTAN/' => 1,
      'https://mirror.dogado.de/tex-archive/' => 1,
      'https://mirror.physik.tu-berlin.de/pub/CTAN/' => 1,
      'https://mirror.rabisu.com/mirrors/CTAN/' => 1,
      'https://satztexnik.com/tex-archive/' => 1,
    },
    'Greece' => {
      'https://fosszone.csd.auth.gr/CTAN/' => 1,
      'https://ftp.cc.uoc.gr/mirrors/CTAN/' => 1,
    },
    'Hungary' => {
      'https://ctan.uni-eszterhazy.hu/tex-archive/' => 1,
    },
    'Italy' => {
      'https://ctan.mirror.garr.it/mirrors/ctan/' => 1,
    },
    'Netherlands' => {
      'https://ftp.snt.utwente.nl/pub/software/tex/' => 1,
      'https://mirror.koddos.net/CTAN/' => 1,
      'https://mirror.koetsier.org/ctan/' => 1,
      'https://mirror.lyrahosting.com/CTAN/' => 1,
      'https://nl.mirrors.cicku.me/ctan/' => 1,
    },
    'Norway' => {
      'https://ctan.uib.no/' => 1,
      'https://ftp.fagskolen.gjovik.no/pub/tex-archive/' => 1,
    },
    'Poland' => {
      'https://ctan.gust.org.pl/tex-archive/' => 1,
      'https://polish-mirror.evolution-host.com/ctan/' => 1,
      'https://sunsite.icm.edu.pl/pub/CTAN/' => 1,
    },
    'Portugal' => {
      'https://ftp.eq.uc.pt/software/TeX/' => 1,
      'https://mirrors.up.pt/pub/CTAN/' => 1,
    },
    'Romania' => {
      'https://mirrors.nxthost.com/ctan/' => 1,
    },
    'Russia' => {
      'https://mirror.macomnet.net/pub/CTAN/' => 1,
      'https://mirror.truenetwork.ru/CTAN/' => 1,
    },
    'Spain' => {
      'https://ctan.fisiquimicamente.com/' => 1,
      'https://ctan.gonzaleztroyano.es/' => 1,
      'https://ctan.javinator9889.com/' => 1,
      'https://mist.dsic.upv.es/tex-archive/' => 1,
      'https://softlibre.unizar.es/tex-archive/' => 1,
    },
    'Sweden' => {
      'https://ftpmirror1.infania.net/mirror/CTAN/' => 1,
      'https://mirror.accum.se/mirror/CTAN/' => 1,
      'https://mirror.bahnhof.net/pub/ctan/' => 1,
    },
    'Switzerland' => {
      'https://ch.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.foobar.to/CTAN/' => 1,
      'https://mirror.init7.net/ctan/' => 1,
    },
    'Turkey' => {
      'https://mirror.alastyr.com/tex-archive/' => 1,
    },
    'United Kingdom' => {
      'https://gb.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.apps.cam.ac.uk/pub/tex-archive/' => 1,
      'https://tex.org.uk/' => 1,
    },
  },
  'North America' => {
    'Canada' => {
      'https://ca.mirrors.cicku.me/ctan/' => 1,
      'https://ctan.mirror.globo.tech/' => 1,
      'https://ctan.mirror.rafal.ca/' => 1,
      'https://mirror.csclub.uwaterloo.ca/CTAN/' => 1,
      'https://mirror.quantum5.ca/CTAN/' => 1,
      'https://muug.ca/mirror/ctan/' => 1,
    },
    'Costa Rica' => {
      'https://mirrors.ucr.ac.cr/CTAN/' => 1,
    },
    'USA' => {
      'http://ctan.mirrors.hoobly.com/' => 1,
      'https://ctan.katoptra.org/' => 1,
      'https://ctan.math.illinois.edu/' => 1,
      'https://ctan.math.utah.edu/ctan/tex-archive/' => 1,
      'https://latex.us/' => 1,
      'https://mirror.clarkson.edu/ctan/' => 1,
      'https://mirror.latigo.net/ctan/' => 1,
      'https://mirror.math.princeton.edu/pub/CTAN/' => 1,
      'https://mirrors.ibiblio.org/pub/mirrors/CTAN/' => 1,
      'https://mirrors.mit.edu/CTAN/' => 1,
      'https://mirrors.rit.edu/CTAN/' => 1,
      'https://us.mirrors.cicku.me/ctan/' => 1,
    },
  },
  'Oceania' => {
    'Australia' => {
      'https://au.mirrors.cicku.me/ctan/' => 1,
      'https://mirror.aarnet.edu.au/pub/CTAN/' => 1,
    },
  },
  'South America' => {
    'Brazil' => {
      'https://br.mirrors.cicku.me/ctan/' => 1,
    },
    'Chile' => {
      'https://ctan.dcc.uchile.cl/' => 1,
    },
    'Dominican Republic' => {
      'https://mirror.hiesoft.net/ctan/' => 1,
    },
  },
};
